# Repository contents

| File / folder | What it is |
|---|---|
| `app.py` | The Streamlit web app (4 pages: model, top 100, compare sites, Jezero vs new sites). Run with `streamlit run app.py` |
| `requirements.txt` | Python packages needed by the app (installed automatically by Streamlit Community Cloud) |
| `top100_final_appli.csv` | Top 100 sites with scores, measurements, clay signal and field check (access, disputed, protected) |
| `classement_final_monde.csv` | All 4,553 candidate sites worldwide with their scores |
| `.streamlit/config.toml` | App theme (dark background, amber accent) |
| `gee/` | Google Earth Engine scripts that produce the CSV files, with their own README |
| `assets/` | Images used in the README |

The app also contains an embedded copy of the data (compressed at the end of `app.py`), so it still runs if the CSV files are missing.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```
